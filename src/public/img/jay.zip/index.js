console.log("Calculator...");
var a =6;
var b= 9;
console.log(a+b);
console.log("Hello Duniya");
console.log("Jay Bhakte");

